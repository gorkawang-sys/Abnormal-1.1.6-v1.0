# -*- coding: utf-8 -*-
"""
Abnormal 插件翻译调试工具

使用方法:
1. 在 Blender 中打开脚本编辑器
2. 加载此文件并运行
3. 查看控制台输出的调试信息
"""

import bpy

def debug_translation():
    """调试翻译系统"""
    
    print("\n" + "="*60)
    print("Abnormal 插件翻译调试信息")
    print("="*60)
    
    # 1. 检查 Blender 语言设置
    print(f"\n1. Blender 语言设置:")
    print(f"   当前语言: {bpy.app.translations.locale}")
    print(f"   支持的语言: {bpy.app.translations.locales}")
    
    # 2. 检查翻译是否已注册
    print(f"\n2. 翻译注册状态:")
    try:
        from . import translations
        print(f"   ✓ translations.py 模块已导入")
        print(f"   翻译字典键: {list(translations.translation_dict.keys())}")
        
        if 'zh_CN' in translations.translation_dict:
            zh_dict = translations.translation_dict['zh_CN']
            print(f"   zh_CN 翻译条目数: {len(zh_dict)}")
            print(f"\n   前5个翻译条目示例:")
            for i, (key, value) in enumerate(list(zh_dict.items())[:5]):
                print(f"     {i+1}. {key} -> {value}")
        else:
            print(f"   ✗ 未找到 zh_CN 翻译字典")
            
    except ImportError as e:
        print(f"   ✗ 无法导入 translations 模块: {e}")
    
    # 3. 测试翻译函数
    print(f"\n3. 测试翻译函数:")
    test_strings = [
        ("Operator", "Start Normal Editor"),
        ("*", "Filter Vertex Group"),
        ("Operator", "Normals  --->  Vertex Colors"),
    ]
    
    for context, text in test_strings:
        try:
            translated = bpy.app.translations.pgettext_iface(text)
            status = "✓" if translated != text else "✗"
            print(f"   {status} '{text}' -> '{translated}'")
        except Exception as e:
            print(f"   ✗ 翻译失败: {e}")
    
    # 4. 检查插件是否已启用
    print(f"\n4. 插件状态:")
    addon_name = "Abnormal"
    addon_found = False
    
    for mod in bpy.context.preferences.addons:
        if addon_name.lower() in mod.module.lower():
            print(f"   ✓ 插件已启用: {mod.module}")
            addon_found = True
            break
    
    if not addon_found:
        print(f"   ✗ 未找到已启用的 {addon_name} 插件")
    
    # 5. 建议
    print(f"\n5. 故障排除建议:")
    
    if bpy.app.translations.locale != 'zh_CN':
        print(f"   ⚠ 当前语言不是简体中文")
        print(f"     请在 编辑 > 偏好设置 > 界面 中设置语言为 '简体中文'")
    
    print(f"   • 如果翻译未生效,请尝试:")
    print(f"     1. 禁用插件")
    print(f"     2. 重启 Blender")
    print(f"     3. 重新启用插件")
    print(f"     4. 查看控制台是否有 '[Abnormal]' 开头的消息")
    
    print("\n" + "="*60)
    print("调试信息输出完毕")
    print("="*60 + "\n")

if __name__ == "__main__":
    debug_translation()
