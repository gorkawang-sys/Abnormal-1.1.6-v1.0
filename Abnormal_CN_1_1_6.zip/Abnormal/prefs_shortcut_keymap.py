import bpy

from bpy.types import PropertyGroup
from bpy.props import *
from .keymap import addon_keymaps


class prefs(PropertyGroup):
    brush_circle_select: BoolProperty(default=False)


def label_row(path, prop, row, label):
    row.label(text=label)
    row.prop(path, prop, text='')


def keymap_row(items, key, row, label):
    row.label(text=label)
    row.prop(items[key], 'type', text='', full_event=True)
    row.prop(items[key], 'value', text='')


def draw(preference, context, layout):
    # label_row(preference.keymap, 'brush_circle_select',
    #           layout.row(), 'Circle Select - Blender Brush Behavior')

    # layout.separator()

    keymap = addon_keymaps[0]
    keymap_items = keymap.keymap_items

    keymap_row(keymap_items, 'Toggle X-Ray', layout.row(), '切换X射线按键')
    keymap_row(keymap_items, 'Toggle Gizmo', layout.row(), '切换操作器按键')
    keymap_row(keymap_items, 'Reset Gizmo Rotation',
               layout.row(), '重置操作器旋转按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Unhide', layout.row(), '显示法线按键')
    keymap_row(keymap_items, 'Hide Selected',
               layout.row(), '隐藏选中法线按键')
    keymap_row(keymap_items, 'Hide Unselected',
               layout.row(), '隐藏未选中法线按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Mirror Normals Start',
               layout.row(), '镜像法线开始按键')
    keymap_row(keymap_items, 'Mirror Normals X',
               layout.row(), '镜像X轴法线按键')
    keymap_row(keymap_items, 'Mirror Normals Y',
               layout.row(), '镜像Y轴法线按键')
    keymap_row(keymap_items, 'Mirror Normals Z',
               layout.row(), '镜像Z轴法线按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Flatten Normals Start',
               layout.row(), '展平法线开始按键')
    keymap_row(keymap_items, 'Flatten Normals X',
               layout.row(), '展平X轴法线按键')
    keymap_row(keymap_items, 'Flatten Normals Y',
               layout.row(), '展平Y轴法线按键')
    keymap_row(keymap_items, 'Flatten Normals Z',
               layout.row(), '展平Z轴法线按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Align Normals Start',
               layout.row(), '对齐法线开始按键')
    keymap_row(keymap_items, 'Align Normals Pos X',
               layout.row(), '对齐法线正X轴按键')
    keymap_row(keymap_items, 'Align Normals Pos Y',
               layout.row(), '对齐法线正Y轴按键')
    keymap_row(keymap_items, 'Align Normals Pos Z',
               layout.row(), '对齐法线正Z轴按键')
    keymap_row(keymap_items, 'Align Normals Neg X',
               layout.row(), '对齐法线负X轴按键')
    keymap_row(keymap_items, 'Align Normals Neg Y',
               layout.row(), '对齐法线负Y轴按键')
    keymap_row(keymap_items, 'Align Normals Neg Z',
               layout.row(), '对齐法线负Z轴按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Smooth Normals',
               layout.row(), '平滑法线按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Copy Active Normal',
               layout.row(), '复制活动法线按键')
    keymap_row(keymap_items, 'Paste Stored Normal',
               layout.row(), '粘贴存储法线按键')
    keymap_row(keymap_items, 'Paste Active Normal to Selected',
               layout.row(), '粘贴活动法线到选中按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Set Normals Outside',
               layout.row(), '设置法线向外按键')
    keymap_row(keymap_items, 'Set Normals Inside',
               layout.row(), '设置法线向内按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Flip Normals', layout.row(), '翻转法线按键')
    keymap_row(keymap_items, 'Reset Vectors',
               layout.row(), '重置矢量按键')
    keymap_row(keymap_items, 'Set Normals From Faces',
               layout.row(), '从面设置法线按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Average Individual Normals',
               layout.row(), '平均单个法线按键')
    keymap_row(keymap_items, 'Average Selected Normals',
               layout.row(), '平均选中法线按键')


def register():
    bpy.utils.register_class(prefs)
    return


def unregister():
    bpy.utils.unregister_class(prefs)
    return
