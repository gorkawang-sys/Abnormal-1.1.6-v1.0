import bpy

from bpy.types import PropertyGroup
from bpy.props import *
from .keymap import addon_keymaps


class prefs(PropertyGroup):
    brush_circle_select: BoolProperty(default=False)


def label_row(path, prop, row, label):
    row.label(text=label)
    row.prop(path, prop, text='')


def keymap_row(items, key, row, label):
    row.label(text=label)
    row.prop(items[key], 'type', text='', full_event=True)
    row.prop(items[key], 'value', text='')


def draw(preference, context, layout):
    # label_row(preference.keymap, 'brush_circle_select',
    #           layout.row(), 'Circle Select - Blender Brush Behavior')

    # layout.separator()

    keymap = addon_keymaps[0]
    keymap_items = keymap.keymap_items

    keymap_row(keymap_items, 'Rotate Normals',
               layout.row(), '旋转法线按键')
    keymap_row(keymap_items, 'Rotate X Axis',
               layout.row(), '旋转X轴按键')
    keymap_row(keymap_items, 'Rotate Y Axis',
               layout.row(), '旋转Y轴按键')
    keymap_row(keymap_items, 'Rotate Z Axis',
               layout.row(), '旋转Z轴按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Target Move Start',
               layout.row(), '目标移动开始按键')
    keymap_row(keymap_items, 'Target Center Reset',
               layout.row(), '目标中心重置按键')
    keymap_row(keymap_items, 'Target Move X Axis',
               layout.row(), '目标移动X轴按键')
    keymap_row(keymap_items, 'Target Move Y Axis',
               layout.row(), '目标移动Y轴按键')
    keymap_row(keymap_items, 'Target Move Z Axis',
               layout.row(), '目标移动Z轴按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Filter Mask From Selected',
               layout.row(), '从选中创建筛选遮罩按键')
    keymap_row(keymap_items, 'Clear Filter Mask',
               layout.row(), '清除筛选遮罩按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Cancel Modal', layout.row(), '取消模态按键')
    keymap_row(keymap_items, 'Confirm Modal',
               layout.row(), '确认模态按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Cancel Tool 1',
               layout.row(), '取消工具按键1')
    keymap_row(keymap_items, 'Cancel Tool 2',
               layout.row(), '取消工具按键2')


def register():
    bpy.utils.register_class(prefs)
    return


def unregister():
    bpy.utils.unregister_class(prefs)
    return
