import bpy

from bpy.types import PropertyGroup
from bpy.props import *
from .keymap import addon_keymaps


class prefs(PropertyGroup):
    brush_circle_select: BoolProperty(default=False)


def label_row(path, prop, row, label):
    row.label(text=label)
    row.prop(path, prop, text='')


def keymap_row(items, key, row, label):
    row.label(text=label)
    row.prop(items[key], 'type', text='', full_event=True)
    row.prop(items[key], 'value', text='')


def draw(preference, context, layout):
    # label_row(preference.keymap, 'brush_circle_select',
    #           layout.row(), 'Circle Select - Blender Brush Behavior')

    # layout.separator()

    keymap = addon_keymaps[0]
    keymap_items = keymap.keymap_items

    keymap_row(keymap_items, 'New Click Selection',
               layout.row(), '新建点击选择按键')
    keymap_row(keymap_items, 'Add Click Selection',
               layout.row(), '添加点击选择按键')
    keymap_row(keymap_items, 'New Loop Selection',
               layout.row(), '新建循环选择按键')
    keymap_row(keymap_items, 'Add Loop Selection',
               layout.row(), '添加循环选择按键')
    keymap_row(keymap_items, 'New Shortest Path Selection',
               layout.row(), '新建最短路径选择按键')
    keymap_row(keymap_items, 'Add Shortest Path Selection',
               layout.row(), '添加最短路径选择按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Invert Selection',
               layout.row(), '反选按键')
    keymap_row(keymap_items, 'Select Linked',
               layout.row(), '选择关联按键')
    keymap_row(keymap_items, 'Select Hover Linked',
               layout.row(), '选择悬停关联按键')
    keymap_row(keymap_items, 'Select All',
               layout.row(), '全选按键')
    keymap_row(keymap_items, 'Deselect All',
               layout.row(), '取消全选按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Box Select Start',
               layout.row(), '框选开始按键')
    keymap_row(keymap_items, 'Box Select Start Selection',
               layout.row(), '框选开始选择按键')
    keymap_row(keymap_items, 'Box New Selection',
               layout.row(), '框选新建选择按键')
    keymap_row(keymap_items, 'Box Add Selection',
               layout.row(), '框选添加选择按键')
    keymap_row(keymap_items, 'Box Remove Selection',
               layout.row(), '框选移除选择按键')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Circle Select Start',
               layout.row(), '圈选开始按键')
    keymap_row(keymap_items, 'Circle Select Start Selection',
               layout.row(), '圈选开始选择按键')
    keymap_row(keymap_items, 'Circle End Selection',
               layout.row(), '圈选结束选择按键')
    keymap_row(keymap_items, 'Circle Add Selection',
               layout.row(), '圈选添加选择按键')
    keymap_row(keymap_items, 'Circle Remove Selection',
               layout.row(), '圈选移除选择按键')

    keymap_row(keymap_items, 'Circle Resize Mode Start',
               layout.row(), '圈选调整大小模式开始按键')
    keymap_row(keymap_items, 'Circle Resize Confirm',
               layout.row(), '圈选调整大小确认按键')

    keymap_row(keymap_items, 'Circle Increase Size 1',
               layout.row(), '圈选增大按键1')
    keymap_row(keymap_items, 'Circle Increase Size 2',
               layout.row(), '圈选增大按键2')
    keymap_row(keymap_items, 'Circle Decrease Size 1',
               layout.row(), '圈选减小按键1')
    keymap_row(keymap_items, 'Circle Decrease Size 2',
               layout.row(), '圈选减小按键2')

    #
    layout.separator()
    #

    keymap_row(keymap_items, 'Lasso Select Start',
               layout.row(), '套索选择开始按键')
    keymap_row(keymap_items, 'Lasso Select Start Selection',
               layout.row(), '套索选择开始选择按键')
    keymap_row(keymap_items, 'Lasso New Selection',
               layout.row(), '套索新建选择按键')
    keymap_row(keymap_items, 'Lasso Add Selection',
               layout.row(), '套索添加选择按键')
    keymap_row(keymap_items, 'Lasso Remove Selection',
               layout.row(), '套索移除选择按键')


def register():
    bpy.utils.register_class(prefs)
    return


def unregister():
    bpy.utils.unregister_class(prefs)
    return
