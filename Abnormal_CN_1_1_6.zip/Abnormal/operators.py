import bpy
from bpy.props import *
from bpy.types import Operator
import numpy as np


class ABN_OT_store_norms_in_vcol(Operator):
    bl_idname = "abnormal.store_norms_in_vcol"
    bl_label = "法线  --->  顶点色"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    bl_description = '将当前自定义法线转换为所选顶点色'

    def execute(self, context):
        scn = context.scene
        aobj = context.active_object

        addon_prefs = bpy.context.preferences.addons[__package__.split('.')[
            0]].preferences

        if addon_prefs.vcol is not None and addon_prefs.vcol in aobj.data.vertex_colors:
            if bpy.app.version[0] <= 4 and bpy.app.version[1] < 1:
                aobj.data.calc_normals_split()

            loop_amnt = len(aobj.data.loops)

            norms = np.zeros(loop_amnt*3, dtype=np.float32)

            aobj.data.loops.foreach_get(
                'normal', norms)

            norms.shape = [loop_amnt, 3]

            alphas = np.ones(loop_amnt, dtype=np.float32).reshape(-1, 1)
            norms = np.hstack((norms, alphas))

            aobj.data.vertex_colors[addon_prefs.vcol].data.foreach_set(
                'color', norms.ravel())

        return {'FINISHED'}


class ABN_OT_convert_vcol_to_norms(Operator):
    bl_idname = "abnormal.convert_vcol_to_norms"
    bl_label = "顶点色  --->  法线"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    bl_description = '将所选顶点色转换为自定义法线'

    def execute(self, context):
        scn = context.scene
        aobj = context.active_object

        addon_prefs = bpy.context.preferences.addons[__package__.split('.')[
            0]].preferences

        if addon_prefs.vcol is not None and addon_prefs.vcol in aobj.data.vertex_colors:
            if bpy.app.version[0] <= 4 and bpy.app.version[1] < 1:
                aobj.data.calc_normals_split()

            loop_amnt = len(aobj.data.loops)

            cols = np.zeros(loop_amnt*4, dtype=np.float32)

            aobj.data.vertex_colors[addon_prefs.vcol].data.foreach_get(
                'color', cols)

            cols.shape = [loop_amnt, 4]

            cols = cols[:, [0, 1, 2]]

            aobj.data.normals_split_custom_set(cols)

        return {'FINISHED'}


class ABN_OT_store_norms_in_attr(Operator):
    bl_idname = "abnormal.store_norms_in_attr"
    bl_label = "法线  --->  面角属性"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    bl_description = '将当前自定义法线转换为所选顶点色'

    def execute(self, context):
        scn = context.scene
        aobj = context.active_object

        addon_prefs = bpy.context.preferences.addons[__package__.split('.')[
            0]].preferences

        if addon_prefs.attribute is None or addon_prefs.attribute not in aobj.data.attributes:
            self.report({"ERROR"}, "设置的属性不存在！")
            return {"CANCELLED"}
        if aobj.data.attributes[addon_prefs.attribute].domain != 'CORNER':
            self.report({"ERROR"}, "设置的属性不是面角域！")
            return {"CANCELLED"}
        if aobj.data.attributes[addon_prefs.attribute].data_type != 'FLOAT_VECTOR':
            self.report({"ERROR"}, "设置的属性不是矢量类型！")
            return {"CANCELLED"}

        if bpy.app.version[0] <= 4 and bpy.app.version[1] < 1:
            aobj.data.calc_normals_split()

        loop_amnt = len(aobj.data.loops)

        norms = np.zeros(loop_amnt*3, dtype=np.float32)

        aobj.data.loops.foreach_get(
            'normal', norms)

        norms.shape = [loop_amnt, 3]

        aobj.data.attributes[addon_prefs.attribute].data.foreach_set(
            'vector', norms.ravel())

        return {'FINISHED'}


class ABN_OT_convert_attr_to_norms(Operator):
    bl_idname = "abnormal.convert_attr_to_norms"
    bl_label = "面角属性  --->  法线"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    bl_description = '将所选顶点色转换为自定义法线'

    def execute(self, context):
        scn = context.scene
        aobj = context.active_object

        addon_prefs = bpy.context.preferences.addons[__package__.split('.')[
            0]].preferences

        if addon_prefs.attribute is None or addon_prefs.attribute not in aobj.data.attributes:
            self.report({"ERROR"}, "设置的属性不存在！")
            return {"CANCELLED"}
        if aobj.data.attributes[addon_prefs.attribute].domain != 'CORNER':
            self.report({"ERROR"}, "设置的属性不是面角域！")
            return {"CANCELLED"}
        if aobj.data.attributes[addon_prefs.attribute].data_type != 'FLOAT_VECTOR':
            self.report({"ERROR"}, "设置的属性不是矢量类型！")
            return {"CANCELLED"}

        if bpy.app.version[0] <= 4 and bpy.app.version[1] < 1:
            aobj.data.calc_normals_split()

        # loop_amnt = len(aobj.data.loops)

        # norms = np.zeros(loop_amnt*3, dtype=np.float32)

        # aobj.data.attributes[addon_prefs.attribute].data.foreach_get(
        #     'vector', norms)
        
        norms = []
        for vec in aobj.data.attributes[addon_prefs.attribute].data:
            norms.append(vec.vector)

        aobj.data.normals_split_custom_set(norms)

        return {'FINISHED'}


def register():
    bpy.utils.register_class(ABN_OT_store_norms_in_vcol)
    bpy.utils.register_class(ABN_OT_convert_vcol_to_norms)
    bpy.utils.register_class(ABN_OT_store_norms_in_attr)
    bpy.utils.register_class(ABN_OT_convert_attr_to_norms)
    return


def unregister():
    bpy.utils.unregister_class(ABN_OT_store_norms_in_vcol)
    bpy.utils.unregister_class(ABN_OT_convert_vcol_to_norms)
    bpy.utils.unregister_class(ABN_OT_store_norms_in_attr)
    bpy.utils.unregister_class(ABN_OT_convert_attr_to_norms)
    return
