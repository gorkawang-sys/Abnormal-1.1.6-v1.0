import bpy
from bpy.props import *
from bpy.types import PropertyGroup, AddonPreferences
from . import prefs_display, prefs_behavior, prefs_sel_keymap, prefs_shortcut_keymap, prefs_tool_keymap
from .ui import update_panel


class AbnormalAddonPreferences(AddonPreferences):
    bl_idname = __package__

    object: StringProperty()
    vertex_group: StringProperty(
        description='用于筛选法线变化的顶点组')
    vcol: StringProperty(
        description='用于写入/读取数据的顶点色')
    attribute: StringProperty(
        description='用于写入/读取数据的属性')

    use_n_panel: BoolProperty(
        default=True, description='使用侧栏选项卡显示插件。如果为False则使用3D视图标题栏', update=update_panel)

    settings: EnumProperty(
        name='设置', description='要显示的设置',
        items=[('PREFS_DISPLAY', '显示', ''),
               ('PREFS_BEHAVIOR', '行为', ''),
               ('PREFS_SEL_KEYMAP', '按键映射-选择', ''),
               ('PREFS_SHORTCUT_KEYMAP', '按键映射-快捷键', ''),
               ('PREFS_TOOL_KEYMAP', '按键映射-工具', '')],
        default='PREFS_DISPLAY')

    behavior: PointerProperty(type=prefs_behavior.prefs)
    display: PointerProperty(type=prefs_display.prefs)
    keymap_sel: PointerProperty(type=prefs_sel_keymap.prefs)
    keymap_shortcut: PointerProperty(type=prefs_shortcut_keymap.prefs)
    keymap_tool: PointerProperty(type=prefs_tool_keymap.prefs)

    def draw(self, context):
        layout = self.layout
        column = layout.column(align=True)
        row = column.row(align=True)
        row.prop(self, 'settings', expand=True)

        box = column.box()
        globals()[self.settings.lower()].draw(self, context, box)


def register():
    prefs_display.register()
    prefs_behavior.register()
    prefs_sel_keymap.register()
    prefs_shortcut_keymap.register()
    prefs_tool_keymap.register()
    bpy.utils.register_class(AbnormalAddonPreferences)
    return


def unregister():
    prefs_display.unregister()
    prefs_behavior.unregister()
    prefs_sel_keymap.unregister()
    prefs_shortcut_keymap.unregister()
    prefs_tool_keymap.unregister()
    bpy.utils.unregister_class(AbnormalAddonPreferences)
    return
