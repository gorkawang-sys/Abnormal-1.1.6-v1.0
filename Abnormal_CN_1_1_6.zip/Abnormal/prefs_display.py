import bpy

from bpy.types import PropertyGroup
from bpy.props import *


class prefs(PropertyGroup):
    selected_only: BoolProperty(default=False)
    selected_scale: BoolProperty(default=True)
    draw_weights: BoolProperty(default=True)
    display_wireframe: BoolProperty(default=True)
    normal_size: FloatProperty(default=0.5, min=0.01, max=10.0)
    point_size: FloatProperty(default=1.0, min=.1, max=10.0)
    loop_tri_size: FloatProperty(default=0.75, min=0.0, max=1.0)
    line_brightness: FloatProperty(default=1.0, min=.01, max=2.0)
    gizmo_size: IntProperty(default=200, min=10, max=1000)
    ui_scale: FloatProperty(default=0.0, min=0.25, max=3.0)

    display_collapsed: BoolProperty(default=True)
    symmetry_collapsed: BoolProperty(default=True)
    alignment_collapsed: BoolProperty(default=True)
    direction_collapsed: BoolProperty(default=True)
    modify_collapsed: BoolProperty(default=True)
    filter_collapsed: BoolProperty(default=True)
    copy_collapsed: BoolProperty(default=True)
    modes_collapsed: BoolProperty(default=True)


def label_row(path, prop, row, label):
    row.label(text=label)
    row.prop(path, prop, text='')


def draw(preference, context, layout):
    label_row(preference.display, 'selected_only',
              layout.row(), '仅显示选中的法线')
    label_row(preference.display, 'selected_scale',
              layout.row(), '缩放选中的法线')
    label_row(preference.display, 'draw_weights',
              layout.row(), '绘制筛选权重')
    label_row(preference.display, 'display_wireframe',
              layout.row(), '显示线框')
    label_row(preference.display, 'normal_size',
              layout.row(), '法线长度')
    label_row(preference.display, 'point_size',
              layout.row(), '点大小')
    label_row(preference.display, 'line_brightness',
              layout.row(), '法线亮度')
    label_row(preference.display, 'gizmo_size',
              layout.row(), '操作器像素大小')
    label_row(preference.display, 'ui_scale',
              layout.row(), '界面缩放')

    label_row(preference.display, 'display_collapsed',
              layout.row(), '折叠视口设置菜单')
    label_row(preference.display, 'symmetry_collapsed',
              layout.row(), '折叠对称菜单')
    label_row(preference.display, 'alignment_collapsed',
              layout.row(), '折叠轴对齐菜单')
    label_row(preference.display, 'direction_collapsed',
              layout.row(), '折叠法线方向菜单')
    label_row(preference.display, 'modify_collapsed',
              layout.row(), '折叠修改法线菜单')
    label_row(preference.display, 'filter_collapsed',
              layout.row(), '折叠筛选菜单')
    label_row(preference.display, 'copy_collapsed',
              layout.row(), '折叠复制/粘贴菜单')
    label_row(preference.display, 'modes_collapsed',
              layout.row(), '折叠法线目标模式菜单')


def register():
    bpy.utils.register_class(prefs)
    return


def unregister():
    bpy.utils.unregister_class(prefs)
    return
